A priori le compresseur et le décompresseur marchent pour les fichiers test.
Pas d'archiveur python.

Paul Bunel Esteban Baron